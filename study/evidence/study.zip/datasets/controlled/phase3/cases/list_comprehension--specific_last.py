value = [
    missing_a(item)
    for item in missing_b  # noqa: F821
]
